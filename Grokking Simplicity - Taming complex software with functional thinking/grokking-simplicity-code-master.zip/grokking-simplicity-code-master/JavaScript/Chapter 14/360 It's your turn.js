/// It's your turn

var user = {
  firstName: "Joe",
  lastName: "Nash",
  email: "JOE@EXAMPLE.COM"
};

/// Answer

update(user, 'email', lowercase)