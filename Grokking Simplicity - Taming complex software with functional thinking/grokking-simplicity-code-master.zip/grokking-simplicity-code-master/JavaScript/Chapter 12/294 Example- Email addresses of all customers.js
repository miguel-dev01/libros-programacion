map(customers, function(customer) {
  return customer.email;
});