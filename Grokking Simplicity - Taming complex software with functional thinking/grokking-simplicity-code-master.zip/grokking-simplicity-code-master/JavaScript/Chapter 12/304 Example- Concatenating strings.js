reduce(strings, "", function(accum, string) {
  return accum + string;
});