var total = 0;

function add_to_total(amount) {
  console.log("Old total: " + total);
  total += amount;
  return total;
}