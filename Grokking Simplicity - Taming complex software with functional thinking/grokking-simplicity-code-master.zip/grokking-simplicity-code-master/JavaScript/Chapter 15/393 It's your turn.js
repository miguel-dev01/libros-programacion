function dinner(food) {
  cook(food);
  serve(food);
  eat(food);
}