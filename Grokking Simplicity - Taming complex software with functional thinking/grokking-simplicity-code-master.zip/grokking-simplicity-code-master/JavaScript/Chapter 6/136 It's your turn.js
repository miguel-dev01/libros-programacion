function setQuantity(item, new_quantity) {
  return objectSet(item, 'quantity', new_quantity);
}