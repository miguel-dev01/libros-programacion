function plus(a, b) {
  return a + b;
}