/// Answer

function times(a, b) {
  return a * b;
}

function dividedBy(a, b) {
  return a / b;
}

function minus(a, b) {
  return a - b;
}