/// It's your turn

function multiplyByFour(x) {
  return x * 4;
}

function multiplyBy12(x) {
  return x * 12;
}

function multiplyBySix(x) {
  return x * 6;
}

function multiplyByPi(x) {
  return x * 3.14159;
}

/// Answer

function multiply(x, y) {
  return x * y;
}