package com.orionsorbits;

import com.mercurymeals.*;

public class OrionsOrbits {

	public static void main(String[] args) throws Exception
	{
		OrionsOrbits oo = new OrionsOrbits();
		System.out.println("Adding order...");
		oo.orderMeal(new String[]{"Fish and Chips"}, "VS01");
	}
	
	public void orderMeal(String[] options, String flightNo)
	throws MealOptionNotFoundException, OrderNotAcceptedException {
		
		// Here's where your code should go.
		
	}
}
