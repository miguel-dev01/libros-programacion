package com.mercurymeals;

public class MercuryMealsConnectionException extends Exception {

}
