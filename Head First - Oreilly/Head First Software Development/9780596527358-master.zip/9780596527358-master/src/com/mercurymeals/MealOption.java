package com.mercurymeals;

public class MealOption {
	
	private String optionName;
	
	public MealOption(String optionName)
	{
		this.optionName = optionName;
	}

}
